Project Structures and Assumptions:-

Project Name is inventory_management
inside Project, created one app where all urls, views, templates, media and models are present.

[
(project) url structure:- http://127.0.0.1:8000/inventory/
from where all inventory with their setting options are showing like,

Add:- Top Most Setting Element, from where we can add Product Details like their Name, Description, Image, Product original price,
Product discounted price.

Delete:- For deleting that Product by that Product ID.
Edit:- For Editing Product Details like their Name, Description, Image, Product original price,
Product discounted price.
Stock Details:- For Viewing Stock Name, and Stock Quantity.
Stock Transfer Details:- For Viewing Stock Name, Stock Quantity, Stock Source, Stock Destination and Stock Transfer Date
Stock Order Details:- For Viewing Order Name, Order Quantity, Order Source and Order Destination


]
User can Do Crud Operations from their Admin Panel too.
admin panel username/password:- 

[
    username: 'lucky'
    password:- 12345
]

I have attached All Screenshots for more clarification.